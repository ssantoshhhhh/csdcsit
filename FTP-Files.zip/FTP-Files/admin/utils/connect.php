<?php

$conn = mysqli_connect('sql302.infinityfree.com', 'if0_39923791', 'WredXibeqKifLM', 'if0_39923791_department');

$sconn = new mysqli('sql302.infinityfree.com', 'if0_39923791', 'WredXibeqKifLM', 'if0_39923791_department');
  
?>