<?php
// Redirect to unified logout
header('Location: logout.php');
exit();
?>
