<?php

// Database configuration
$db_host = 'sql302.infinityfree.com'; // e.g., 'localhost' or your server IP
$db_user = 'if0_39923791'; // Your database username
$db_pass = 'WredXibeqKifLM'; // Your database password
$db_name = 'if0_39923791_department'; // Your database name

// Attempt to connect to the database
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// Check the connection
if (!$conn) {
    // If you are seeing this, it means the credentials in connect.php are wrong.
    // 1. Open connect.php
    // 2. Replace YOUR_DATABASE_HOST, YOUR_DATABASE_USER, etc. with your live server's details.
    // 3. If you don't know them, contact your hosting provider.
    die("Database connection failed: Unable to connect to the database. Please check your configuration.");
}

// Create a new mysqli object for other parts of the application that might use it
$sconn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check the object-oriented connection
if ($sconn->connect_error) {
    die("Database connection failed (mysqli object): " . $sconn->connect_error);
}
  
?>


